//
//  CasinoLobby.h
//  CasinoLobby
//
//  Created by Mihai Eros on 14.11.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for CasinoLobby.
FOUNDATION_EXPORT double CasinoLobbyVersionNumber;

//! Project version string for CasinoLobby.
FOUNDATION_EXPORT const unsigned char CasinoLobbyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CasinoLobby/PublicHeader.h>


